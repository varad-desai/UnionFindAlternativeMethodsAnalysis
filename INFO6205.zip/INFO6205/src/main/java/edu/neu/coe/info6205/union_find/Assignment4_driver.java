package edu.neu.coe.info6205.union_find;

import java.util.Random;
import java.util.function.Consumer;
import java.util.function.UnaryOperator;

import edu.neu.coe.info6205.util.Benchmark_Timer;

public class Assignment4_driver {
	
	private static final int N = 200;
	private static final int DOUBLING_TIMES = 12;
	private static final int NO_OF_RUNS = 100;
	
	public static void main (String[] args) {
		
		System.out.println("\n" + "Comparison Between Height Weighted Quick Find vs Size Weighted Quick Find!" + "\n");
		
		String[] UnionFindMethods = {"WQUPC", "HWQUPC1"};
		
		for(String unionFindMethod : UnionFindMethods) {
			System.out.println("Union find method used: "+unionFindMethod);
			int SIZE = N;
			for(int i=1; i<=DOUBLING_TIMES; i++) {
				
				int pairsGenerated = count(SIZE, NO_OF_RUNS, unionFindMethod);
				System.out.println(i+": Count of Pairs = "+pairsGenerated+" for Size = "+SIZE);
				SIZE = SIZE*2;
			}
		}
		
		System.out.println("\n" + "Benchmarking of No Compression Quick Find vs Total Compression Quick Find!" + "\n");
		
		//pre function
    	UnaryOperator<Integer> pre = input -> input;
    	
    	//functions to be benchmarked
    	Consumer<Integer> func1 = input -> count(input,1,"HWQU");
    	Consumer<Integer> func2 = input -> count(input,1,"WQUPC");
    	
    	//post function
    	Consumer<Integer> post = input -> System.out.print("");
    	
    	Benchmark_Timer<Integer> t1 = new Benchmark_Timer<>("QU No Compression Benchmark",pre,func1,post);   //no compression
    	Benchmark_Timer<Integer> t2 = new Benchmark_Timer<>("QU Total Compression Benchmark",pre,func2,post); //path compression

    	int SIZE = N;
    	
    	for(int i=1; i<=DOUBLING_TIMES; i++) {
			
			SIZE = SIZE*2;
			
			System.out.println(i+": SIZE = "+ SIZE);
			
			System.out.println(t1.run(SIZE,NO_OF_RUNS));
			
			System.out.println(t2.run(SIZE,NO_OF_RUNS));
			
    	}
	}
	
	/**
     * Counts number of random pairs generated for connecting all the n nodes
     * @param n -> number of nodes in a run
     * @param runs -> number of runs
     * @return average number of pairs generated for all the runs
     */
    private static int count(int n, int runs, String unionFindMethod) {
    	
    	int averageCount=0;
    	UF uf = null;
    	
    	for(int i=0; i<runs; i++) {
    		int totalCount = 0;
    		
    	
    		if (unionFindMethod == "HWQU") { // Height Weighted, no path compression
    			uf = new UF_HWQUPC(n, false);
    		} else if (unionFindMethod == "WQUPC") { // Weight Weighted, full compression
    			uf = new WQUPC(n);
    		} else if (unionFindMethod == "HWQUPC1") { // Height Weighted, path halving
    			uf = new UF_HWQUPC(n, true);
    		}
    		
    		
    		while(uf.components()>1) {
    			int[] randomPair = getPairOfRandomNumbers(n);
    			uf.connect(randomPair[0], randomPair[1]);
    			totalCount++;
    		}
    		averageCount += totalCount;
    	}
    	averageCount = averageCount/runs;
    	return averageCount;
    }
    
    /**
     * Generates random pair of integers
     * @param n -> total number of random integers to be generated
     * @return int[] -> array of random integers
     */
    private static int[] getPairOfRandomNumbers(int n) {
    	Random rand = new Random();
    	
    	int[] randomPair = new int[2];
    	randomPair[0] = rand.nextInt(n);
    	randomPair[1] = rand.nextInt(n);
    	
    	return randomPair;
    }
	
}
