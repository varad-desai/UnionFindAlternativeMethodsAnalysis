/**
 * Original code:
 * Copyright © 2000–2017, Robert Sedgewick and Kevin Wayne.
 * <p>
 * Modifications:
 * Copyright (c) 2017. Phasmid Software
 */
package edu.neu.coe.info6205.union_find;

import java.util.Arrays;
import java.util.Random;

/**
 * Height-weighted Quick Union with Path Compression
 */
public class UF_HWQUPC implements UF {
    
    private final int[] parent;   // parent[i] = parent of i
    private final int[] height;   // height[i] = height of subtree rooted at i
    private int count;  // number of components
    private boolean pathCompression;
//    private int pathCompressionMode = 0; // 0 -> no path compression, 1 -> path halving, 2 -> total path compression
    

    /**
     * Initializes an empty union–find data structure with {@code n} sites
     * {@code 0} through {@code n-1}. Each site is initially in its own
     * component.
     *
     * @param n               the number of sites
     * @param pathCompression whether to use path compression
     * @throws IllegalArgumentException if {@code n < 0}
     */
    public UF_HWQUPC(int n, boolean pathCompression) {
        count = n;
        parent = new int[n];
        height = new int[n];
        for (int i = 0; i < n; i++) {
            parent[i] = i;
            height[i] = 1;
        }
        this.pathCompression = pathCompression;
    }
    
//    public UF_HWQUPC(int n, int pathCompressionMode) {
//        count = n;
//        parent = new int[n];
//        height = new int[n];
//        for (int i = 0; i < n; i++) {
//            parent[i] = i;
//            height[i] = 1;
//        }`
//        this.pathCompressionMode = pathCompressionMode;
//    }

    /**
     * Initializes an empty union–find data structure with {@code n} sites
     * {@code 0} through {@code n-1}. Each site is initially in its own
     * component.
     * This data structure uses path compression
     *
     * @param n the number of sites
     * @throws IllegalArgumentException if {@code n < 0}
     */
    public UF_HWQUPC(int n) {
        this(n, true);
    }
    
    public void show() {
        for (int i = 0; i < parent.length; i++) {
            System.out.printf("%d: %d, %d\n", i, parent[i], height[i]);
        }
    }
    
    private void updateParent(int p, int x) {
        parent[p] = x;
    }

    private void updateHeight(int p, int x) {
        height[p] += height[x];
    }

    /**
     * Used only by testing code
     *
     * @param i the component
     * @return the parent of the component
     */
    private int getParent(int i) {
        return parent[i];
    }











    /**
     * Returns true if the the two sites are in the same component.
     *
     * @param p the integer representing one site
     * @param q the integer representing the other site
     * @return {@code true} if the two sites {@code p} and {@code q} are in the same component;
     * {@code false} otherwise
     * @throws IllegalArgumentException unless
     *                                  both {@code 0 <= p < n} and {@code 0 <= q < n}
     */
    public boolean connected(int p, int q) {
        return find(p) == find(q);
    }



    @Override
    public int size() {
        return parent.length;
    }

    /**
     * Used only by testing code
     *
     * @param pathCompression true if you want path compression
     */
    public void setPathCompression(boolean pathCompression) {
        this.pathCompression = pathCompression;
    }

    @Override
    public String toString() {
        return "UF_HWQUPC:" + "\n  count: " + count +
                "\n  path compression? " + pathCompression +
                "\n  parents: " + Arrays.toString(parent) +
                "\n  heights: " + Arrays.toString(height);
    }






    private void mergeComponents(int i, int j) {
        // TO BE IMPLEMENTED make shorter root point to taller one
    	if (height[i] < height[j]) {
    		parent[i] = j;
            height[j] = height[j] + height[i];
        } else {
        	parent[j] = i;
            height[i] = height[i] + height[j];
        }
    }


  
    public static void main(String args[]) {
    	int NO_OF_RUNS = 100;
    	int SIZE = 200; // Number of Sites
    	int DOUBLING_TIMES = 15;
    	
    	System.out.println("Starting Union Find");
    	
    	for(int i=0; i<DOUBLING_TIMES; i++) {
    		int resultCount = count(SIZE, NO_OF_RUNS);
    		System.out.println((i+1) +": Count = "+ resultCount +" for Size = "+ SIZE);
    		SIZE = SIZE * 2;
    	}
    	
    }
    
    private static int count(int n, int runs) {
    	
    	int averageCount=0;
    	
    	for(int i=0; i<runs; i++) {
    		int totalCount = 0;
    		UF uf = new UF_HWQUPC(n, true);
    		while(uf.components()>1) {
    			int[] randomPair = getPairOfRandomNumbers(n);
    			uf.connect(randomPair[0], randomPair[1]);
    			totalCount++;
    		}
    		averageCount += totalCount;
    	}
    	averageCount = averageCount/runs;
    	return averageCount;
    }
    
    /**
     * Returns the number of components.
     *
     * @return the number of components (between {@code 1} and {@code n})
     */
    public int components() {
        return count;
    }
    
    
    private static int[] getPairOfRandomNumbers(int n) {
    	Random rand = new Random();
    	
    	int[] randomPair = new int[2];
    	randomPair[0] = rand.nextInt(n);
    	randomPair[1] = rand.nextInt(n);
    	
    	return randomPair;
    }
    
	/**
     * Ensure that site p is connected to site q,
     *
     * @param p the integer representing one site
     * @param q the integer representing the other site
     */
    public void connect(int p, int q) {
        if (!isConnected(p, q)) union(p, q);
    }
    
    /**
     * Merges the component containing site {@code p} with the
     * the component containing site {@code q}.
     *
     * @param p the integer representing one site
     * @param q the integer representing the other site
     * @throws IllegalArgumentException unless
     *                                  both {@code 0 <= p < n} and {@code 0 <= q < n}
     */
    public void union(int p, int q) {
        // CONSIDER can we avoid doing find again?
        mergeComponents(find(p), find(q));
        count--;
    }
    
    /**
     * Returns the component identifier for the component containing site {@code p}.
     *
     * @param p the integer representing one site
     * @return the component identifier for the component containing site {@code p}
     * @throws IllegalArgumentException unless {@code 0 <= p < n}
     */
    public int find(int p) {
        validate(p);
        int root = p;
        
//        // TO BE IMPLEMENTED 1 --> path halving
        while(root != parent[root]) {
        	if(pathCompression) {
        		parent[root] = parent[parent[root]];
        	}
            root = parent[root];
        }
        if(!pathCompression) {
            return root;
        }
        
        // TO BE IMPLEMENTED 2 --> total compression
        
//        if(pathCompression == false) {
//            return root;
//        } else {
////        	System.out.println("A");
//        	int ultimateRoot = root;
//        	while(parent[ultimateRoot] != ultimateRoot) {
////            	System.out.println("B");
//        		ultimateRoot = parent[ultimateRoot];
//        	}
//        	int tempRoot = root;
//        	while(root != parent[root]) {
////            	System.out.println("C");
//        		int temp = parent[root];
//        		parent[root] = ultimateRoot;
//        		root = temp;
//        	}
//        }
        
        return root;
    }
    
    // validate that p is a valid index
    private void validate(int p) {
        int n = parent.length;
        if (p < 0 || p >= n) {
            throw new IllegalArgumentException("index " + p + " is not between 0 and " + (n - 1));
        }
    }

//    /**
//     * Finds root of p while performing path compression as indicated 
//     * @param p -> node for which root is to be found
//     * @param pathCompressionMode -> Path Compression Mode specified
//     * @return root of p
//     */
//    public int find(int p, int pathCompressionMode) {
//    	validate(p);
//    	int root = p;
//    	
//    	if(pathCompressionMode == 0) {
//    		return root;
//    	} else if(pathCompressionMode == 1) {
//    		doPathCompression(p);
//    		return root;
//    	} else if(pathCompressionMode == 2) {
//    		doTotalPathCompression(p);
//    		return root;
//    	}
//    	
//    	return root;
//    }
    
    /**
     * This implements the single-pass path-halving mechanism of path compression
     */
    private void doPathCompression(int i) {
        // TO BE IMPLEMENTED update parent to value of grandparent
    	int thisNode = find(i);
    	int grandParent = parent[parent[thisNode]];
    	parent[thisNode] = grandParent;
    }
    
//    /**
//     * This implements the single-pass total Compression 
//     * i.e. all the parents of the leaf node will point to the ultimate parent
//     * @param i
//     */
//    private void doTotalPathCompression(int i) {
//    	
//    	// current node
//    	int thisNode = find(i); 
//    	
//    	// initialize ultimate parent as thisNode
//    	int ultimateParent = thisNode; 
//    	
//    	// find ultimate parent for thisNode
//    	while(parent[ultimateParent] != ultimateParent) { 
//    		ultimateParent = parent[ultimateParent];
//    	}
//    	
//    	// make all parents of thisNode point to ultimate parent
//    	int tempThisNode = thisNode;
//    	while(parent[tempThisNode] != tempThisNode) { 
//    		int temp = parent[tempThisNode];
//    		parent[tempThisNode] = ultimateParent;
//    		tempThisNode = temp;
//    	}
//    }
    
}
